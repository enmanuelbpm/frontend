import React from "react";

function Aside() {
  return (
    <aside className="aside">
      <h3>Aside</h3>
      <p>Información complementaria.</p>
    </aside>
  );
}

export default Aside;