import React from "react";

function Section() {
  return (
    <section className="section">
      <h2>Segunda Sección</h2>
      <p>Contenido adicional de la página.</p>
    </section>
  );
}

export default Section;