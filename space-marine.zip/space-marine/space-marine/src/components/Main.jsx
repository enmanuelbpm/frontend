import React from "react";

function Main() {
  return (
    <main className="main">
      <h2>Sección Principal</h2>
      <p>Este es el contenido principal de la aplicación.</p>
    </main>
  );
}

export default Main;