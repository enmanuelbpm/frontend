import React from "react";

function Navbar() {
  return (
    <nav className="navbar">
      <h1>Mi Sitio React</h1>
      <ul>
        <li>Inicio</li>
        <li>Servicios</li>
        <li>Contacto</li>
      </ul>
    </nav>
  );
}

export default Navbar;