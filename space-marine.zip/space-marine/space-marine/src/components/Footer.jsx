import React from "react";

function Footer() {
  return (
    <footer className="footer">
      <p>© 2026 Mi Sitio Web</p>
    </footer>
  );
}

export default Footer;