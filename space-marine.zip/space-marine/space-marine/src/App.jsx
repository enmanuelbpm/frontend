import React from "react";
import Navbar from "./components/Navbar";
import Main from "./components/Main";
import Section from "./components/Section";
import Aside from "./components/Aside";
import Footer from "./components/Footer";

function App() {
  return (
    <div>
      <Navbar />
      <Main />
      <Section />
      <Aside />
      <Footer />
    </div>
  );
}

export default App;